<?php
include_once 'config.php';
include_once 'Database/index.php';
include_once 'Core/index.php';
include_once 'Controller/index.php';
?>




<?php include_once 'header.php' ?>

     <section>
          <div class="container">
               <div class="text-center">
                 
                    <h1>500</h1>

                    <br>
               </div>
          </div>
     </section>



<?php include_once 'footer.php' ?>