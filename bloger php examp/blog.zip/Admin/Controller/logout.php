<?php
session_destroy();

?>
